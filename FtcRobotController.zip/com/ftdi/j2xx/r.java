package com.ftdi.j2xx;

class r {
   public byte a;
   public byte b;
   public byte c;
   public byte d;
}
