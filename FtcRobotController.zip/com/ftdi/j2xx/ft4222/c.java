package com.ftdi.j2xx.ft4222;

class c {
   byte a;
   byte b;
   byte[] c = new byte[3];
}
