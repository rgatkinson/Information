package com.ftdi.j2xx.ft4222;

class a {
   int a;
   int b;
   int c;
   int d;
   byte e;
}
