package com.ftdi.j2xx.ft4222;

import com.ftdi.j2xx.ft4222.c;

class d {
   c a = new c();
   byte b;
   byte c;
   byte[] d = new byte[1];
}
