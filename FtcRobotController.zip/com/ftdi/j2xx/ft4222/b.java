package com.ftdi.j2xx.ft4222;

class b {
   byte a;
   byte b;
   byte c;
   byte d;
   byte e;
   byte f;
   byte g;
   byte h;
   byte i;
   byte j;
   byte[] k = new byte[3];

   void a(byte[] var1) {
      this.a = var1[0];
      this.b = var1[1];
      this.c = var1[2];
      this.d = var1[3];
      this.e = var1[4];
      this.f = var1[5];
      this.g = var1[6];
      this.h = var1[7];
      this.i = var1[8];
      this.j = var1[9];
      this.k[0] = var1[10];
      this.k[1] = var1[11];
      this.k[2] = var1[12];
   }
}
