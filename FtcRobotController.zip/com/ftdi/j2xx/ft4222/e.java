package com.ftdi.j2xx.ft4222;

class e {
   int[] a = new int[4];
   int[] b = new int[4];
   byte c;
}
