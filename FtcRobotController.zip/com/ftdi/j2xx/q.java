package com.ftdi.j2xx;

class q {
   public long a;
}
