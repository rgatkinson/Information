package com.ftdi.j2xx;

import com.ftdi.j2xx.FT_EEPROM;

public class FT_EEPROM_2232D extends FT_EEPROM {
   public boolean A_FIFO = false;
   public boolean A_FIFOTarget = false;
   public boolean A_FastSerial = false;
   public boolean A_HighIO = false;
   public boolean A_LoadD2XX = false;
   public boolean A_LoadVCP = false;
   public boolean A_UART = false;
   public boolean B_FIFO = false;
   public boolean B_FIFOTarget = false;
   public boolean B_FastSerial = false;
   public boolean B_HighIO = false;
   public boolean B_LoadD2XX = false;
   public boolean B_LoadVCP = false;
   public boolean B_UART = false;
}
