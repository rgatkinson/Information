package com.qualcomm.ftccommon;

public interface Restarter {
   void requestRestart();
}
