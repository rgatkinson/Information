package com.qualcomm.ftccommon;

public class LaunchActivityConstantsList {
   public static final int FTC_ROBOT_CONTROLLER_ACTIVITY_CONFIGURE_ROBOT = 3;
   public static final String VIEW_LOGS_ACTIVITY_FILENAME = "Filename";
   public static final String ZTE_WIFI_CHANNEL_EDITOR_PACKAGE = "com.zte.wifichanneleditor";
}
