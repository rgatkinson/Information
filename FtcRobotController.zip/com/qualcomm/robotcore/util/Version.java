package com.qualcomm.robotcore.util;

public class Version {
   public static final String LIBRARY_VERSION = "15.11.04";

   public static String getLibraryVersion() {
      return "15.11.04";
   }
}
