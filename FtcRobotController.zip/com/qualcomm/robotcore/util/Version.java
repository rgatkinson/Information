package com.qualcomm.robotcore.util;

public class Version {
   public static final String LIBRARY_VERSION = "15.09.18";

   public static String getLibraryVersion() {
      return "15.09.18";
   }
}
