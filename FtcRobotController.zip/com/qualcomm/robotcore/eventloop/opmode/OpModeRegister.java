package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.robotcore.eventloop.opmode.OpModeManager;

public interface OpModeRegister {
   void register(OpModeManager var1);
}
