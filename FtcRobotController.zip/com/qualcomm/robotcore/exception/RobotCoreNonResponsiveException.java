package com.qualcomm.robotcore.exception;

import com.qualcomm.robotcore.exception.RobotCoreException;

public class RobotCoreNonResponsiveException extends RobotCoreException {
   public RobotCoreNonResponsiveException(String var1) {
      super(var1);
   }
}
