package com.qualcomm.analyticsmodule;

public final class R {
   public static final class color {
      public static final int black = 2131230720;
      public static final int bright_red = 2131230722;
      public static final int bright_red_text = 2131230723;
      public static final int dark_red_background = 2131230724;
      public static final int light_red_background = 2131230726;
      public static final int medium_red_background = 2131230727;
      public static final int transparent_color = 2131230728;
      public static final int very_bright_red = 2131230729;
      public static final int white = 2131230730;
   }

   public static final class string {
      public static final int app_name = 2131296265;
   }

   public static final class style {
      public static final int AppBaseTheme = 2131099648;
      public static final int AppTheme = 2131099649;
   }
}
